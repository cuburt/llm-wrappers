from typing import List, Dict
from langchain.schema.vectorstore import VectorStore
from langchain.docstore.document import Document
import pinecone
import logging
from text_embeddings import TextEmbeddings
from langchain.vectorstores import Pinecone
from langchain.vectorstores import FAISS
from adapter import ArxivStoreAdapter
from langchain.schema.document import Document


class VoltScriptStore:
    def __init__(self, docs: List[Document]):
        logging.info("initialising vector database...")
        self.docs = docs
        self.vectorstore = FAISS.from_documents(self.docs, TextEmbeddings('sentence-transformers/all-MiniLM-L6-v2'))

    def insert_doc(self, text: str, filename: str="/"):
        doc = Document(page_content=text, metadata= {"filename": filename, "row_index":len(self.docs)++})
        self.docs.append(doc)
        super().__init__(self.docs)

    def insert_docs(self, texts: List[Dict]):
        docs = []
        for i in range(1, len(texts)):
            doc = Document(page_content=texts['text'], metadata= {"filename": texts[filename], "row_index":len(self.docs)+i})
            docs.append(doc)
        self.docs.extend(docs)
        super().__init__(self.docs)
        
        

class LotusScriptStore:
    def __init__(self):
        logging.info("initialising vector database...")
        pinecone.init(api_key="2d28174b-3585-4f42-a524-31d5fdaf1888",
                      environment="gcp-starter")
        index = pinecone.Index('lotusscript-docs')
        embed_model = TextEmbeddings('sentence-transformers/all-MiniLM-L6-v2')
        label = 'text'
        # vectorstore
        self.vectorstore = Pinecone(
            index, embed_model.embed_query, label
        )


class VoltMXStore:
    def __init__(self):
        logging.info("initialising vector database...")
        pinecone.init(
            api_key='c126a016-cb0d-45e1-b371-1121e27e4d25',
            environment='us-west4-gcp-free'
        )
        index = pinecone.Index('voltmx-docs')
        embed_model = TextEmbeddings('sentence-transformers/all-MiniLM-L6-v2')
        label = 'text'
        # vectorstore
        self.vectorstore = Pinecone(
            index, embed_model.embed_query, label
        )


class ArxivStore(VectorStore):

    def _post(self, payload, headers):

        result = ArxivStoreAdapter().post(payload=payload, headers=headers, endpoint=":predict")
        return result

    def _get(self, payload, headers):

        result = ArxivStoreAdapter().get(payload=payload, headers=headers)
        return result

    def similarity_search(self, query) -> List[Document]:
        payload = ArxivStoreAdapter().build_payload(query)
        headers = ArxivStoreAdapter().build_headers()
        docs = []
        results = self._post(payload, headers)
        for res in results["predictions"]:
            # metadata = res["metadata"]
            # if self._text_key in metadata:
            #     text = metadata.pop(self._text_key)
            #     score = res["score"]
            score=res[:6]
            score = float(score.replace(': ',''))
            text=res[6:]
            docs.append(Document(page_content=str(text)))
            # else:
            #     logger.warning(
            #         f"Found document with no `{self._text_key}` key. Skipping."
            #     )
        return docs

    def add_texts(self):
        return True

    def from_texts(self):
        return True