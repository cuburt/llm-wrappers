from langchain.chains import RetrievalQA
from llm import PalmLLM, GeminiLLM, CodeyLLM
from output_parser import CodeInterpreterSchema
import re
import os
import sys
import traceback
from io import StringIO
import contextlib
import tempfile
import random
import shutil
from e2b import Sandbox
from vector_index import VoltMXStore, ArxivStore, LotusScriptStore, VoltVectorStore
import document_loader as docloader


class InterpreterError(Exception):
    pass


class TimeoutException(Exception):
    pass


@contextlib.contextmanager
def stdoutIO(stdout=None):
    old = sys.stdout
    if stdout is None:
        stdout = StringIO()
    sys.stdout = stdout
    yield stdout
    sys.stdout = old


@contextlib.contextmanager
def chdir(root):
    if root == ".":
        yield
        return
    cwd = os.getcwd()
    os.chdir(root)
    try:
        yield
    except BaseException as exc:
        raise exc
    finally:
        os.chdir(cwd)


@contextlib.contextmanager
def create_tempdir():
    with tempfile.TemporaryDirectory() as dirname:
        with chdir(dirname):
            yield dirname


def my_exec(cmd, globals=None, locals=None, description='source string'):
    try:
        with stdoutIO() as s:
            exec(cmd, globals, locals)

        return s.getvalue()

    except SyntaxError as err:
        error_class = err.__class__.__name__
        detail = err.args[0]
        line_number = err.lineno
        raise Exception("%s at line %d of %s: %s" % (error_class, line_number, description, detail))

    except Exception as err:
        error_class = err.__class__.__name__
        detail = err.args[0]
        cl, exc, tb = sys.exc_info()
        line_number = traceback.extract_tb(tb)[-1][1]
        raise Exception("%s at line %d of %s: %s" % (error_class, line_number, description, detail))


class DXAgent:
    """
        required fields:
        index: pinecone object
        embed_model: model object
        label: str
        """

    def __init__(self):

        # chat completion llm
        self.llm = PalmLLM()
        self.output_schema = CodeInterpreterSchema()

        # retrieval qa chain
        self.qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=ArxivStore().as_retriever(),
            return_source_documents=True,
            input_key="input",
            output_key="output"
        )

        # tool
        # tools = [
        #     Tool(
        #         name='Fashion Knowledge',
        #         func=self.run_qa_chain,
        #         description=(
        #             # 'use this tool when giving clothing or fashion recommendations'
        #             'use this tool when checking the availability of fashion items or when recommending available fashion items'
        #         )
        #     )
        # ]

    def run_qa_chain(self, query):
        output = self.qa_chain({"input": query}, return_only_outputs=True)
        return output

    def format_query(self, query):
        """
        Formats query with a template instruction.
        """
        formatted_prompt = self.output_schema.prompt.format(query=query)
        return formatted_prompt

    def __call__(self, query):
        final_step = []
        contained = []
        source_docs = []
        res = ""

        response = self.run_qa_chain(query)
        print(response)
        # final_step = response['intermediate_steps'][-1] if response['intermediate_steps'] else []
        source_docs = [x.page_content for x in response['source_documents']]
        # contained =  [{self.label: x.page_content, 'metadata': x.metadata} for x in [d for d in source_docs if source_docs]]
        res = response["output"]

        return res, source_docs

class IQAgent:

    @staticmethod
    def build_qa_chain(llm, vectordb):
        """
        retriever's constructor
        """

        return RetrievalQA.from_chain_type(
            llm=llm,
            chain_type="stuff",
            retriever=vectordb.vectorstore.as_retriever(),
            return_source_documents=True,
            input_key="input",
            output_key="output"
        )

    @staticmethod
    def run_qa_chain(qa_chain, query):
        """
        retriever's function. can be used in function calling or as agent tool
        """

        output = qa_chain({"input": query}, return_only_outputs=True)
        return output

    def __init__(self):
        """
        Initialize LLM, Code Interpreter's prompt template, vector store, and retriever.
        """

        # chat completion llm
        self.palm = PalmLLM()
        self.gemini = GeminiLLM()
        self.codey = CodeyLLM()
        self.output_schema = CodeInterpreterSchema()
        voltmx_vectorstore = VoltVectorStore(docloader.txt_to_list_of_docs(dir="./data/texts"))
        lotuscript_vectorstore = VoltVectorStore(docloader.crawled_csv_to_list_of_docs(dir="./data/lotusscript_tutorials"))
        voltscript_vectorstore = VoltVectorStore(docloader.column_in_csv_to_list_of_docs(file="./data/voltscript/code_data.csv", col="code", metadata_cols=['filename']))

        """
        To insert new documents: 
        voltmx_vectorstore.insert_docs(List[Dict]) -> voltmx_vectorstore.insert_docs([{"text": text, "metadata": metadata}])
        voltmx_vectorstore.add_documents(List[Documents]) -> voltmx_vectorstore.add_documents(docloader.txt_to_list_of_docs(dir="directory_to_textfiles"))
        
        """

        self.palm_voltmx_chain = self.build_qa_chain(self.palm, voltmx_vectorstore)
        self.gemini_voltmx_chain = self.build_qa_chain(self.gemini, voltmx_vectorstore)

        self.palm_lotus_chain = self.build_qa_chain(self.palm, lotuscript_vectorstore)
        self.gemini_lotus_chain = self.build_qa_chain(self.gemini, lotuscript_vectorstore)

        self.codey_volt_chain = self.build_qa_chain(self.codey, voltscript_vectorstore)

        # tool
        # tools = [
        #     Tool(
        #         name='Fashion Knowledge',
        #         func=self.run_qa_chain,
        #         description=(
        #             # 'use this tool when giving clothing or fashion recommendations'
        #             'use this tool when checking the availability of fashion items or when recommending available fashion items'
        #         )
        #     )
        # ]

    def format_query(self, query):
        """
        Formats query with a template instruction.
        """

        formatted_prompt = self.output_schema.prompt.format(query=query)
        return formatted_prompt

    def run_code(self, response_palm, timeout: float = 3.0, tmp_dir: str = None):
        """
        Evaluates the functional correctness of a completion by running the test
        suite provided in the problem.
        """

        try:
            parsed_output = self.output_schema.output_parser.parse(response_palm)
        except:
            try:
                parsed_response_palm = re.sub(r"(?<!\\)\\'", "'", response_palm)
                parsed_output = self.output_schema.output_parser.parse(parsed_response_palm)
            except:
                try:
                    response_dic = response_palm[response_palm.find("{"):response_palm.find("}") + 1]
                    parsed_output = eval(response_dic.replace('null', '""'))
                except:
                    parsed_output = {}
                    parsed_output['bot_response'] = response_palm

        if 'code' in parsed_output and parsed_output['code'] and parsed_output['code'] != "" and "python" in parsed_output['code']:

            code = parsed_output['code']

            if "```python" in code:
                code = code.replace('```python', '')

            if "```" in code[len(code) - 5:]:
                code = code.replace('```', '')

            python_exec = None
            try:
                # WARNING
                # This program exists to execute untrusted model-generated code. Although
                # it is highly unlikely that model-generated code will do something overtly
                # malicious in response to this test suite, model-generated code may act
                # destructively due to a lack of model capability or alignment.
                # Users are strongly encouraged to sandbox this evaluation suite so that it
                # does not perform destructive actions on their host or network.
                # Once you have read this disclaimer and taken appropriate precautions,
                # uncomment the following line and proceed at your own risk:
                python_exec = my_exec(code)

            except Exception as e:
                python_exec = str(e)

            out = python_exec
            in_append = str(parsed_output['bot_response']) if parsed_output['bot_response'] else ""
            out_append = "\n\n\n Output from sandbox runtime: " + str(out) if out else "\n\n\n No output expected."
            code = code if code not in parsed_output['bot_response'] else ""
            code_start = "\n```python\n" if code and "```python" not in code else ""
            code_end = "\n```\n" if code and "```" not in code[len(code) - 5:] else ""
            res = in_append + code_start + code + code_end + out_append

        elif 'code' in parsed_output and parsed_output['code'] and parsed_output['code'] != "" and "js" in \
                parsed_output['code']:
            code = parsed_output['code']

            if "```js" in code:
                code = code.replace('```js', '')

            if "```" in code[len(code) - 5:]:
                code = code.replace('```', '')

            try:
                # WARNING
                # This program exists to execute untrusted model-generated code. Although
                # it is highly unlikely that model-generated code will do something overtly
                # malicious in response to this test suite, model-generated code may act
                # destructively due to a lack of model capability or alignment.
                # Users are strongly encouraged to sandbox this evaluation suite so that it
                # does not perform destructive actions on their host or network.
                # Once you have read this disclaimer and taken appropriate precautions,
                # uncomment the following line and proceed at your own risk:
                sandbox = Sandbox(api_key="e2b_29a1369676909e50be7dcfede4120ec8d4a72de7")
                sandbox.filesystem.write("/home/user/test.js", code)
                exec_result = sandbox.process.start("node test.js")
                exec_result.wait()
                sandbox.close()

                if exec_result.stderr:
                    err = exec_result.stderr
                    raise Exception(f"failed: {err}")
                elif exec_result.stdout:
                    out = exec_result.stdout
                else:
                    out = "No expected output"

            except TimeoutException:
                out = "Timed out"

            except Exception as e:
                out = str(e)

            in_append = str(parsed_output['bot_response']) if parsed_output['bot_response'] else ""
            out_append = "\n\n\n Output from sandbox runtime: " + str(out) if out else "\n\n\n No output expected."
            code = code if code not in parsed_output['bot_response'] else ""
            code_start = "\n```js\n" if code and "```js" not in code else ""
            code_end = "\n```\n" if code and "```" not in code[len(code) - 5:] else ""
            res = in_append + code_start + code + code_end + out_append

        else:
            res = parsed_output['bot_response']

        return res

    def __call__(self, query, llm='gemini', task='docs'):
        """
        Invoked for RAG response. For non-RAG response, invoke LLM directly.
        """

        response = self.run_qa_chain(self.gemini_voltmx_chain, query)
        if llm == 'palm' and task == 'docs':
            response = self.run_qa_chain(self.palm_voltmx_chain, query)
        elif llm == 'palm' and task == 'code':
            response = self.run_qa_chain(self.palm_lotus_chain, query)
        elif llm == 'gemini' and task == 'code':
            response = self.run_qa_chain(self.gemini_lotus_chain, query)

        source_docs = [x.page_content for x in response['source_documents']]
        res = response["output"]

        return res, source_docs