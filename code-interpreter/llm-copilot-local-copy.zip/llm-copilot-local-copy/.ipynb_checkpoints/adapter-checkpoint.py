import requests
from flask import request
import json
import urllib.parse

class Adapter:

    def __init__(self):
        self.url = request.base_url

    def post(self, payload, headers=None, endpoint=''):
        try:
            if headers:
                result = requests.post(urllib.parse.unquote_plus(self.url + endpoint).replace('%3A',':'), headers=headers, data=payload)
            else:
                result = requests.post(urllib.parse.unquote_plus(self.url + endpoint).replace('%3A',':'), data=payload)
            return result.json()

        except Exception:
            return {}

    def get(self, payload, headers, endpoint=''):
        try:
            result = requests.get(self.url + endpoint, headers=headers, data=payload)
            return result.json()

        except Exception:
            return {}

class ArxivStoreAdapter(Adapter):

    def __init__(self):
        self.host = "content-recommendation.default.example.com"
        self.url = "http://35.245.68.44/v1/models/ContentRecommendation"

    def build_headers(self):
        headers = {}
        if self.host:
            headers = {"host": self.host}
        return headers

    def build_payload(self, title:str="", body:str=""):
        payload = {"title": title,
                   "body": body}

        return json.dumps(payload)


class IQAgentAdapter(Adapter):

    def __init__(self):
        self.url = request.base_url

    def build_payload(self, enable_rag:bool=True, query:str=""):
        payload = {"enable_rag": enable_rag,
                   "query": query}

        return json.dumps(payload)