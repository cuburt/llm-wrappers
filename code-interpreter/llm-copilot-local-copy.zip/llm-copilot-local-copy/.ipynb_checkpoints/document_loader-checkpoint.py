from typing import List
import pandas as pd
import glob
from langchain.schema.document import Document


def txt_to_list_of_str(dir: str="") -> List[str]:
    list_of_texts = []
    for file in glob.glob(dir+"*.txt"):
        with open(file, "r") as ifile:
            texts = []
            for line in ifile:
                # if not line.strip():
                #     breakd
                texts.append(line)
            # print(" ".join(texts))
        list_of_texts.append(" ".join(texts))

    return list_of_texts


def txt_to_list_of_docs(dir: str="") -> List[Document]:
    list_of_docs = []
    for file in glob.glob(dir+"*.txt"):
        with open(file, "r") as ifile:
            texts = []
            for line in ifile:
                texts.append(line)
        doc = Document(page_content=" ".join(texts))
        list_of_docs.append(doc)

    return list_of_docs


def crawled_csv_to_list_of_str(dir: str="") -> List[str]:
    list_of_texts = []
    for i, df in enumerate([pd.read_csv(csv) for csv in glob.glob(dir+"*.csv")]):
        for column in df.columns:
            for r in df[column].unique():
                if r is not None or r != pd.nan:
                    list_of_texts.append(r)

    return list_of_texts


def crawled_csv_to_list_of_docs(dir: str="") -> List[Document]:
    list_of_docs = []
    for i, df in enumerate([pd.read_csv(csv) for csv in glob.glob(dir+"*.csv")]):
        for column in df.columns:
            for r in df[column].unique():
                if r is not None or r != pd.nan:
                    doc = Document(page_content=" ".join(r))
                    list_of_docs.append(doc)

    return list_of_docs


def column_in_csv_to_list_of_docs(col:str, metadata_cols: List[str], file:str) -> List[Document]:
    df = pd.read_csv(file)
    docs = []
    for i in range(0, len(df[col].values)):
        doc = Document(page_content=df[col].values[i], metadata={col: df[col].values[i] for col in metadata_cols})
        docs.append(doc)

    return docs
